
# Trestle-ready Policy-as-Code for Azure Key Vault & Managed HSM Guardrails

This folder packages **Azure Policy** definitions, an **initiative** (policy set), and **assignment templates**
that enforce the guardrails used by the OSCAL component-definition for Azure Key Vault / Managed HSM.

## Structure
```
policy/
  definitions/
    kv-rbac-only.json
    kv-purge-softdelete.json
    kv-public-disabled.json
    kv-diags-law.json
    kv-firewall-deny-audit.json
    mhsm-no-public-purge.json
    kv-allowed-locations.json
  initiatives/
    init-kv-guardrails.json   # template (placeholders replaced by the script)
  assignments/
    assign-init-kv-guardrails-sub.json  # template
    assign-init-kv-guardrails-mg.json   # template
scripts/
  create-and-assign.sh       # end-to-end creation and assignment helper
```

## Guardrails (why these)
- **RBAC (data-plane) over legacy access policies** for least privilege & PIM integration.
- **Private Endpoints / Firewall** to restrict data-plane exposure.
- **Soft-delete (90d) & Purge Protection** to prevent destructive loss.
- **Diagnostics → Log Analytics** to capture `AuditEvent` and metrics for monitoring/Sentinel.
- **Region allow-list** to keep data in Canada Central/East (adjust as needed).

Refer to Microsoft guidance:
- RBAC vs access policies (Key Vault): https://learn.microsoft.com/azure/key-vault/general/rbac-access-policy
- Network security, firewall, private endpoints: https://learn.microsoft.com/azure/key-vault/general/network-security
- Soft-delete overview & changes: https://learn.microsoft.com/azure/key-vault/general/soft-delete-overview
- Monitor / Insights / Logging: https://learn.microsoft.com/azure/key-vault/general/monitor-key-vault ; https://learn.microsoft.com/azure/key-vault/general/logging
- Availability & paired regions (for planning): https://learn.microsoft.com/azure/key-vault/general/disaster-recovery-guidance ; https://learn.microsoft.com/azure/reliability/regions-paired

## Use
1. **Edit variables** at the top of `scripts/create-and-assign.sh`.
2. Run the script:
   ```bash
   ./scripts/create-and-assign.sh
   ```
   This will create policy definitions in your subscription, generate the initiative by injecting the actual definition IDs, and assign the initiative at your management group (and optionally at subscription).

3. Verify compliance in **Azure Policy** → **Compliance**, and verify diagnostics in **Log Analytics** (tables: `AzureDiagnostics`, `AZKVAuditLogs`).

## Notes
- The initiative template contains placeholders like `__POLICY_ID_*__` which the script replaces at runtime.
- For non-Canada deployments, adjust `kv-allowed-locations.json` or remove from the initiative.
- These policies cover both **Key Vault vaults** and **Managed HSM** where applicable.

