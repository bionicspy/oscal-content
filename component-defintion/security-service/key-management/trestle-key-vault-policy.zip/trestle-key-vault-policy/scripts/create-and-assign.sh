
#!/usr/bin/env bash
set -euo pipefail

# ===== Variables to set =====
SUB_ID="${SUB_ID:-<SUBSCRIPTION_ID>}"
MG_ID="${MG_ID:-/providers/Microsoft.Management/managementGroups/<MG_ID>}"
LAW_ID="${LAW_ID:-<LOG_ANALYTICS_WORKSPACE_RESOURCE_ID>}"
LOCATION="${LOCATION:-canadacentral}"

# ===== Create policy definitions =====
BASE_DIR="$(cd "$(dirname "$0")"/.. && pwd)"
DEF_DIR="$BASE_DIR/policy/definitions"

create_def() {
  local name="$1"; shift
  az policy definition create     --name "$name"     --display-name "$name"     --mode All     --rules "$DEF_DIR/$name.json"     --subscription "$SUB_ID" >/dev/null
  az policy definition show --name "$name" --subscription "$SUB_ID" --query id -o tsv
}

ID_KV_RBAC_ONLY=$(create_def kv-rbac-only)
ID_KV_PURGE_SOFTDELETE=$(create_def kv-purge-softdelete)
ID_KV_PUBLIC_DISABLED=$(create_def kv-public-disabled)
ID_KV_DIAGS_LAW=$(create_def kv-diags-law)
ID_KV_FIREWALL_DENY_AUDIT=$(create_def kv-firewall-deny-audit)
ID_MHSM_NO_PUBLIC_PURGE=$(create_def mhsm-no-public-purge)
ID_KV_ALLOWED_LOCATIONS=$(create_def kv-allowed-locations)

echo "Created policy definitions:" >&2
printf "  %s
"   "$ID_KV_RBAC_ONLY"   "$ID_KV_PURGE_SOFTDELETE"   "$ID_KV_PUBLIC_DISABLED"   "$ID_KV_DIAGS_LAW"   "$ID_KV_FIREWALL_DENY_AUDIT"   "$ID_MHSM_NO_PUBLIC_PURGE"   "$ID_KV_ALLOWED_LOCATIONS" >&2

# ===== Create initiative (policy set) =====
INIT_NAME="init-kv-guardrails"
INIT_DEF="$BASE_DIR/policy/initiatives/$INIT_NAME.json"
INIT_TMP=$(mktemp)

sed -e "s#__POLICY_ID_KV_RBAC_ONLY__#$ID_KV_RBAC_ONLY#g"     -e "s#__POLICY_ID_KV_PURGE_SOFTDELETE__#$ID_KV_PURGE_SOFTDELETE#g"     -e "s#__POLICY_ID_KV_PUBLIC_DISABLED__#$ID_KV_PUBLIC_DISABLED#g"     -e "s#__POLICY_ID_KV_DIAGS_LAW__#$ID_KV_DIAGS_LAW#g"     -e "s#__POLICY_ID_KV_FIREWALL_DENY_AUDIT__#$ID_KV_FIREWALL_DENY_AUDIT#g"     -e "s#__POLICY_ID_MHSM_NO_PUBLIC_PURGE__#$ID_MHSM_NO_PUBLIC_PURGE#g"     -e "s#__POLICY_ID_KV_ALLOWED_LOCATIONS__#$ID_KV_ALLOWED_LOCATIONS#g"     "$INIT_DEF" > "$INIT_TMP"

az policy set-definition create   --name "$INIT_NAME"   --definitions "$INIT_TMP"   --display-name "INIT | Azure Key Vault & Managed HSM Guardrails"   --subscription "$SUB_ID" >/dev/null

INIT_ID=$(az policy set-definition show --name "$INIT_NAME" --subscription "$SUB_ID" --query id -o tsv)

echo "Initiative created: $INIT_ID" >&2

# ===== Assign initiative at MG (preferred) =====
az policy assignment create   --name assign-init-kv-guardrails-mg   --scope "$MG_ID"   --policy "$INIT_ID"   --params "{
    "logAnalytics": {"value": "$LAW_ID"},
    "minRetentionDays": {"value": 90},
    "allowedLocations": {"value": ["canadacentral","canadaeast"]}
  }"   --location "$LOCATION" >/dev/null || true

echo "Assignment at MG created (or already exists)." >&2

# ===== Optionally assign at subscription =====
# az policy assignment create #   --name assign-init-kv-guardrails-sub #   --scope "/subscriptions/$SUB_ID" #   --policy "$INIT_ID" #   --params "{
#     "logAnalytics": {"value": "$LAW_ID"},
#     "minRetentionDays": {"value": 90},
#     "allowedLocations": {"value": ["canadacentral","canadaeast"]}
#   }" #   --location "$LOCATION"

echo "Done." >&2
